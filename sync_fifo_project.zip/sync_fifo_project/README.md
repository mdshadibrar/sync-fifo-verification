# Synchronous FIFO — RTL Design, Verification, and Regression Automation

A parameterized synchronous FIFO written in Verilog, verified with a self-checking
testbench against a software golden model, and wrapped in a Tcl-based regression
script for automated compile/simulate/pass-fail reporting.

Built to practice the full RTL-to-verification-to-automation flow: design, write a
testbench that checks itself instead of requiring manual waveform inspection, and
script the whole thing so it can run unattended (e.g. in CI).

## Project Structure

```
sync_fifo_project/
├── rtl/
│   └── sync_fifo.v          # Parameterized synchronous FIFO (DUT)
├── tb/
│   └── tb_sync_fifo.v       # Self-checking testbench with golden reference model
├── scripts/
│   └── run_regression.tcl   # Tcl automation: compile -> simulate -> pass/fail report
├── sim/                      # Simulation outputs (compiled binary, VCD, log) — generated
└── README.md
```

## Design (`rtl/sync_fifo.v`)

A single-clock-domain FIFO, parameterized by data width and depth (depth must be a
power of 2). Key design decisions:

- **Write/read gating**: writes are dropped (not queued or overwritten) when the
  FIFO is full, and reads are gated when empty — protects data integrity rather
  than relying on the testbench/user to never violate these conditions.
- **Combinational `full`/`empty` flags** derived from a registered `fifo_count`,
  which is updated by a `case` statement handling all four combinations of
  simultaneous read/write (write-only, read-only, both, neither) so the count
  stays correct even when read and write happen on the same cycle.

## Verification (`tb/tb_sync_fifo.v`)

Rather than eyeballing waveforms, the testbench maintains its own software queue
(a SystemVerilog `queue` construct) as a **golden reference model**, and checks
every value read from the DUT against what the reference model expects.

Test scenarios covered:

1. Basic single write/read
2. Fill to full, verify the `full` flag asserts correctly
3. Write while full — confirm it's gated and doesn't corrupt state
4. Drain to empty, verify strict FIFO ordering and the `empty` flag
5. Read while empty — confirm it's gated safely
6. A 200-cycle randomized stress test mixing writes and reads

**A real bug I hit and fixed while building this**: my first version of the
testbench sampled the DUT's `full`/`empty` flags *after* issuing a write/read
instead of *before* — meaning the golden model's bookkeeping was checking state
one cycle too late relative to when the DUT actually made its accept/reject
decision. This passed the simple directed tests but broke under the randomized
stress test (39 mismatches). Fixed by sampling `full`/`empty` immediately before
asserting `wr_en`/`rd_en`, matching the actual point where the DUT gates the
operation. Left as a reminder that directed tests alone aren't enough — the
randomized test is what actually caught this.

## Automation (`scripts/run_regression.tcl`)

A Tcl script that:

1. Compiles the RTL + testbench with Icarus Verilog
2. Runs the simulation
3. Parses the pass/fail summary out of the simulation log
4. Exits with status code `0` (pass) or `1` (fail), so it can be dropped into a CI
   pipeline or shell script that checks `$?`
5. Writes a full simulation log to `sim/regression.log` for debugging

## How to Run

Requires [Icarus Verilog](http://iverilog.icarus.com/) and Tcl.

```bash
# Install (Debian/Ubuntu)
sudo apt-get install iverilog gtkwave tcl

# Run the full regression
tclsh scripts/run_regression.tcl
```

Expected output ends with:

```
==================================================
 REGRESSION PASSED
==================================================
```

To inspect waveforms after a run:

```bash
gtkwave sim/sync_fifo_tb.vcd
```

## What This Demonstrates

- RTL design in Verilog with parameterization
- Self-checking testbench methodology (golden reference model, not just
  eyeballing signals)
- Directed + randomized (constrained-random-style) test scenarios
- Debugging a real timing/synchronization bug in a verification environment
- Tcl scripting for simulation automation and regression reporting
