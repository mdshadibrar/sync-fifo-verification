// ============================================================
// Module: sync_fifo
// Description: Parameterized synchronous FIFO with full/empty
//              flags. Single clock domain. Write-when-full and
//              read-when-empty are gated (no-ops) to protect
//              pointer/data integrity.
// ============================================================

module sync_fifo #(
    parameter DATA_WIDTH = 8,
    parameter DEPTH      = 16                     // must be a power of 2
) (
    input  wire                   clk,
    input  wire                   rst_n,          // active-low synchronous reset

    input  wire                   wr_en,
    input  wire [DATA_WIDTH-1:0]  wr_data,

    input  wire                   rd_en,
    output reg  [DATA_WIDTH-1:0]  rd_data,

    output wire                   full,
    output wire                   empty,
    output wire [$clog2(DEPTH):0] count           // number of valid entries
);

    localparam PTR_WIDTH = $clog2(DEPTH);

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    reg [PTR_WIDTH-1:0] wr_ptr, rd_ptr;
    reg [PTR_WIDTH:0]   fifo_count;

    // ---------------- Write logic ----------------
    always @(posedge clk) begin
        if (!rst_n) begin
            wr_ptr <= 0;
        end else if (wr_en && !full) begin
            mem[wr_ptr] <= wr_data;
            wr_ptr      <= wr_ptr + 1'b1;
        end
    end

    // ---------------- Read logic ----------------
    always @(posedge clk) begin
        if (!rst_n) begin
            rd_ptr  <= 0;
            rd_data <= {DATA_WIDTH{1'b0}};
        end else if (rd_en && !empty) begin
            rd_data <= mem[rd_ptr];
            rd_ptr  <= rd_ptr + 1'b1;
        end
    end

    // ---------------- Count / flags ----------------
    always @(posedge clk) begin
        if (!rst_n) begin
            fifo_count <= 0;
        end else begin
            case ({(wr_en && !full), (rd_en && !empty)})
                2'b10:   fifo_count <= fifo_count + 1'b1; // write only
                2'b01:   fifo_count <= fifo_count - 1'b1; // read only
                default: fifo_count <= fifo_count;        // both or neither: net zero
            endcase
        end
    end

    assign full  = (fifo_count == DEPTH);
    assign empty = (fifo_count == 0);
    assign count = fifo_count;

endmodule
