# ============================================================
# run_regression.tcl
#
# Automates the compile + simulate + result-check flow for the
# sync_fifo testbench. Written to be simulator-tool-agnostic in
# spirit (compile/sim commands isolated into variables) even
# though the reference flow below targets Icarus Verilog, since
# that's a freely runnable open-source simulator.
#
# Usage:
#   tclsh scripts/run_regression.tcl
#
# Exits with status 0 if the regression passes, 1 if it fails,
# so this can be wired into a CI job (e.g. a shell script or
# Jenkins/GitHub Actions step checking $?).
# ============================================================

set project_root [file dirname [file dirname [file normalize [info script]]]]
set rtl_file      "$project_root/rtl/sync_fifo.v"
set tb_file       "$project_root/tb/tb_sync_fifo.v"
set sim_dir       "$project_root/sim"
set sim_out       "$sim_dir/sync_fifo_tb.vvp"
set log_file      "$sim_dir/regression.log"

file mkdir $sim_dir

puts "=================================================="
puts " sync_fifo regression run"
puts " Project root : $project_root"
puts " RTL          : $rtl_file"
puts " Testbench    : $tb_file"
puts "=================================================="

# ---------------- Step 1: Compile ----------------
puts "\n\[STEP 1/2\] Compiling design + testbench with Icarus Verilog..."

set compile_cmd "iverilog -g2012 -o $sim_out $rtl_file $tb_file"
puts "  Running: $compile_cmd"

if { [catch {exec {*}$compile_cmd} compile_result] } {
    puts "\n\[REGRESSION FAILED\] Compilation error:"
    puts $compile_result
    exit 1
}
puts "  Compile: OK"

# ---------------- Step 2: Simulate ----------------
puts "\n\[STEP 2/2\] Running simulation..."

set sim_cmd "vvp $sim_out"
puts "  Running: $sim_cmd"

set sim_output ""
catch {exec {*}$sim_cmd} sim_output

# Log full output for debugging/waveform-review purposes
set fh [open $log_file "w"]
puts $fh $sim_output
close $fh
puts "  Full simulation log written to: $log_file"

# ---------------- Step 3: Parse pass/fail ----------------
puts "\n\[RESULT PARSING\]"

if { [regexp {RESULT: ALL TESTS PASSED} $sim_output] } {
    # Extract the summary line for a clean report
    regexp {TESTBENCH SUMMARY: (\d+) checks run, (\d+) errors} $sim_output -> num_checks num_errors
    puts "  Checks run : $num_checks"
    puts "  Errors     : $num_errors"
    puts "\n=================================================="
    puts " REGRESSION PASSED"
    puts "=================================================="
    exit 0
} else {
    regexp {TESTBENCH SUMMARY: (\d+) checks run, (\d+) errors} $sim_output -> num_checks num_errors
    puts "  Checks run : $num_checks"
    puts "  Errors     : $num_errors"
    puts "\n=================================================="
    puts " REGRESSION FAILED -- see $log_file for details"
    puts "=================================================="
    exit 1
}
